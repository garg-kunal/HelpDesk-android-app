package com.example.helpdesk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    String emailId,password;
    EditText email,pwd;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth = FirebaseAuth.getInstance();

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = findViewById(R.id.email);
                emailId =email.getText().toString();
                pwd= findViewById(R.id.pwd);
                password= pwd.getText().toString();

                if(TextUtils.isEmpty(emailId)|| TextUtils.isEmpty(password))
                    Toast.makeText(MainActivity.this,"Please Enter the values",Toast.LENGTH_SHORT).show();
                else
                    auth.signInWithEmailAndPassword(emailId,password).addOnCompleteListener(MainActivity.this,new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "login", Toast.LENGTH_SHORT).show();
                                Intent intent =new Intent(MainActivity.this,Start.class);
                                startActivity(intent);
                                finish();
                            }
                            else
                                Toast.makeText(MainActivity.this,"Enter correct values",Toast.LENGTH_SHORT).show();
                        }
                    });


            }
        });

        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Register.class);
                startActivity(intent);
            }
        });
    }
}
