package com.example.helpdesk;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import javax.annotation.Nullable;

public class Start extends AppCompatActivity {
    TextView name1,email1,phn1;
    FirebaseAuth auth;
    FirebaseFirestore fstore;
    String userId;
    private Uri imgUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
           name1=findViewById(R.id.name);
           email1= findViewById(R.id.email);
           email1.setText("bye");
           fstore =FirebaseFirestore.getInstance();
           auth =FirebaseAuth.getInstance();

               phn1=findViewById(R.id.phn);
               userId= auth.getCurrentUser().getUid();
        email1.setText(userId);
        fstore.collection("users").document(userId).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                 name1.setText(documentSnapshot.getString("Name"));
                 email1.setText(documentSnapshot.getString("Email"));
                 phn1.setText(documentSnapshot.getString("phn_no"));
            }
        });


        findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(Start.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
