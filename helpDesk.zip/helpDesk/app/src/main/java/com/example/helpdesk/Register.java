package com.example.helpdesk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    String emailId,phnId,pwdId,nameID,userId;
    EditText memail,mpass,mname,mphnno;
    FirebaseAuth auth;
    FirebaseFirestore fstore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        memail= findViewById(R.id.email);
        mname= findViewById(R.id.name);
       mphnno= findViewById(R.id.phn);
       mpass= findViewById(R.id.pwd);

        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               emailId= memail.getText().toString();
                nameID=mname.getText().toString();
                phnId=mphnno.getText().toString();
                auth= FirebaseAuth.getInstance();
                fstore=FirebaseFirestore.getInstance();
                pwdId=mpass.getText().toString();
                if(TextUtils.isEmpty(emailId)||TextUtils.isEmpty(pwdId))
                    Toast.makeText(Register.this,"Fill The Fields",Toast.LENGTH_SHORT).show();
                else if(pwdId.length()<6)
                    Toast.makeText(Register.this,"password tooo short",Toast.LENGTH_SHORT).show();
                else
                    auth.createUserWithEmailAndPassword(emailId,pwdId).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                userId=auth.getCurrentUser().getUid();
                                DocumentReference df= fstore.collection("users").document(userId);
                                Map<String,Object> map= new HashMap<>();
                                map.put("Name",nameID);
                                map.put("Email",emailId);
                                map.put("phn_no",phnId);
                                df.set(map);



                                Toast.makeText(Register.this,"Registered",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Register.this,MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });


            }
        });
    }
}
